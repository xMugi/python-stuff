update.py - inside the .py on line 6 replace game_id /w steamgameid (default stellaris id)
also
url_mod_collection.json - multiple urls supported just expand the list and make sure url is between ""

updated_entrys.json - needs {} so dont change anything

also without any of the 3 json it crashes, soooooo 